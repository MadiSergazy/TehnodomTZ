package server

import (
	"net/http"
	"time"

	"project/config"
	"project/internal/logger"
)

func NewServer(mux http.Handler) *http.Server {
	return &http.Server{
		Addr:         config.C.Server.Port,
		Handler:      mux,
		ErrorLog:     logger.ErrorLog,
		WriteTimeout: time.Second * 5,
		ReadTimeout:  time.Second * 5,
		IdleTimeout:  time.Second * 5,
	}
}
