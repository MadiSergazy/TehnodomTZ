package util

import (
	"database/sql"
	"fmt"
	"log"
	"os"

	migrate "project/db"

	_ "github.com/mattn/go-sqlite3"
)

func DBTest(p string) (*sql.DB, error) {
	dir, err := os.ReadDir(p)
	if err != nil {
		return nil, err
	}

	db, err := sql.Open("sqlite3", ":memory:")
	if err != nil {
		return nil, err
	}

	if err := migrate.CreateTable(db, "../../db/migrations"); err != nil {
		return nil, err
	}

	for _, file := range dir {
		info, err := file.Info()
		if err != nil {
			return nil, err
		}

		data, err := os.ReadFile(fmt.Sprintf("%s/%s", p, info.Name()))
		if err != nil {
			return nil, err
		}
		if _, err := db.Exec(string(data)); err != nil {
			log.Printf("file name: %s\terr: %v", info.Name(), err)
		}
	}

	return db, nil
}
