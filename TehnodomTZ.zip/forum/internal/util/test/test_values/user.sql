INSERT INTO Users (name,email,password)
VALUES
("Marvin","sed.nec@hotmail.ca","RCU26WXQ6XN"),
("Sybil","ante.dictum@icloud.net","NRL45MXL4RP"),
("Raja","sodales.purus@yahoo.com","NEZ81RWC5BC"),
("Ray","luctus@protonmail.net","NHV72UFV7CZ"),
("Zenaida","non.lobortis@protonmail.com","IHF27BCM7RT"),
("Nolan","egestas.blandit.nam@aol.couk","BKT18ERI3TW"),
("Wallace","dignissim.lacus.aliquam@yahoo.edu","DDT26NGA2AT"),
("Leigh","sed.eu@google.edu","NTU47DRX8HK"),
("Samson","a@hotmail.com","HOT26KJS3XY"),
("Dorothy","pede.ac.urna@icloud.org","WSN30MTE6RY");
