INSERT INTO Comments (user_id,post_id,parent_id,content)
VALUES
(1,4,3,"vel sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque tincidunt"),
(2,4,5,"arcu. Vestibulum ante ipsum primis in faucibus"),
(3,2,2,"lobortis quis, pede. Suspendisse dui. Fusce"),
(4,4,1,"ac mattis semper, dui lectus rutrum urna, nec luctus felis"),
(5,2,5,"Fusce diam nunc, ullamcorper eu,"),
(6,4,2,"nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum"),
(7,3,5,"tincidunt congue"),
(8,4,5,"augue, eu"),
(9,4,3,"sollicitudin adipiscing ligula. Aenean gravida"),
(10,1,2,"habitant morbi tristique senectus et netus et malesuada");