INSERT INTO Reactions_Comments (user_id,comment_id,type)
VALUES (10,9,0),(2,2,1),(5,2,-1),(9,3,1),(9,3,0),(10,2,-1),(2,7,0),(6,3,-1),(2,8,0),(1,5,0);
