INSERT INTO Posts(user_id,create_att,title,content)
VALUES
(1,"Jan 9, 2023","lobortis","arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum"),
(2,"Dec 30, 2022","lectus pede,","facilisis vitae, orci. Phasellus dapibus"),
(3,"Jul 10, 2022","imperdiet","Donec dignissim magna"),
(4,"Jun 23, 2023","purus, accumsan","eu, ultrices sit amet, risus. Donec nibh"),
(5,"Oct 13, 2023","non","bibendum fermentum metus. Aenean sed pede nec ante"),
(6,"Oct 28, 2022","felis eget","Maecenas ornare egestas"),
(7,"Jun 10, 2023","semper","Aenean euismod mauris eu elit. Nulla facilisi. Sed"),
(8,"Jul 22, 2022","condimentum. Donec","viverra. Maecenas iaculis aliquet diam. Sed diam"),
(9,"Aug 27, 2022","non, cursus","mi eleifend egestas. Sed"),
(10,"Dec 28, 2022","nisi. Aenean","imperdiet ornare.");