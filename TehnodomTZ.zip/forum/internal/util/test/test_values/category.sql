INSERT INTO Categories (name)
VALUES ('go'),('news'),('rust'),('sport'),('temp');