INSERT INTO Categories_Posts (post_id,category_id)
VALUES (7,1),(6,2),(5,2),(4,4),(10,5),(10,3),(2,4),(4,5),(3,3),(5,4);
