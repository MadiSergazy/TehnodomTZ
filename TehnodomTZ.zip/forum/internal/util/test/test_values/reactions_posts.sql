INSERT INTO Reactions_Posts (user_id,post_id,type)
VALUES (3,7,-1),(7,6,0),(3,5,0),(10,4,-1),(3,10,-1),(6,10,1),(3,2,0),(1,4,1),(9,3,0),(9,5,1);
