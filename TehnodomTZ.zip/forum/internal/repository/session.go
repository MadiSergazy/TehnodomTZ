package repository

import (
	"database/sql"

	"project/internal/model"
)

type sessionRepo struct {
	db *sql.DB
}

func NewSessionRepository(db *sql.DB) model.SessionRepository {
	return &sessionRepo{
		db: db,
	}
}

func (s *sessionRepo) CreateSession(session *model.Session) error {
	query := `
	INSERT INTO Session (user_id ,token ,session_end_time)
	VALUES (? ,? ,?);`

	stmt, err := s.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(session.UserId, session.Token, session.EndAtt)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}

	id, err := res.LastInsertId()
	if err != nil {
		return err
	}

	session.Id = id

	return nil
}

func (s *sessionRepo) ReadSessionById(session *model.Session) error {
	query := `SELECT * FROM Session WHERE id = ?`

	stmt, err := s.db.Prepare(query)
	if err != nil {
		return err
	}
	row := stmt.QueryRow(session.Id)

	if err := row.Err(); err != nil {
		return err
	}

	return session.ScanRow(row)
}

func (s *sessionRepo) ReadSessionByUserId(session *model.Session) error {
	query := `SELECT * FROM Session WHERE user_id = ?`

	stmt, err := s.db.Prepare(query)
	if err != nil {
		return err
	}
	row := stmt.QueryRow(session.UserId)

	if err := row.Err(); err != nil {
		return err
	}

	return session.ScanRow(row)
}

func (s *sessionRepo) UpdateSessionEndAtt(session *model.Session) error {
	query := `
	UPDATE Session SET session_end_time = ?
	WHERE id = ?`
	stmt, err := s.db.Prepare(query)
	if err != nil {
		return err
	}
	res, err := stmt.Exec(session.EndAtt, session.Id)
	if err != nil {
		return err
	}

	row, err := res.RowsAffected()
	if err != nil {
		return err
	}

	if row != 1 {
		return model.ErrNotExec
	}

	return nil
}

func (s *sessionRepo) DeleteSession(session *model.Session) error {
	query := `DELETE FROM Session WHERE id =?`

	stmt, err := s.db.Prepare(query)
	if err != nil {
		return err
	}
	res, err := stmt.Exec(session.Id)
	if err != nil {
		return err
	}

	row, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if row != 1 {
		return model.ErrNotExec
	}

	return nil
}
