package repository

import (
	"database/sql"

	"project/internal/model"
)

type categoryRepo struct {
	db *sql.DB
}

func NewCategoryRepository(db *sql.DB) model.CategoryRepository {
	return &categoryRepo{
		db: db,
	}
}

func (c *categoryRepo) CreateCategory(category model.Category) (*model.Category, error) {
	query := `
	INSERT INTO Categories (name)
	VALUES (?);`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	res, err := stmt.Exec(category.Name)
	if err != nil {
		return nil, err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return nil, err
	}
	if rows != 1 {
		return nil, sql.ErrNoRows
	}

	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}

	category.Id = id

	return &category, nil
}

func (c *categoryRepo) GetCategoryByName(name string) (*model.Category, error) {
	category := model.Category{}
	query := `SELECT * FROM Categories WHERE name = ?;`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	row := stmt.QueryRow(name)

	if err := row.Err(); err != nil {
		return nil, err
	}

	if err := category.ScanRow(row); err != nil {
		return nil, err
	}

	return &category, nil
}

func (c *categoryRepo) GetCategoryById(id int64) (*model.Category, error) {
	category := model.Category{}
	query := `SELECT * FROM Categories WHERE id = ?`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}
	row := stmt.QueryRow(id)

	if err := row.Err(); err != nil {
		return nil, err
	}

	if err := category.ScanRow(row); err != nil {
		return nil, err
	}

	return &category, nil
}

/////////////////////////////////

func (c *categoryRepo) CreateCategoryOnPost(postId, categoryId int64) error {
	query := `
	INSERT INTO Categories_Posts (post_id,category_id)
	VALUES (?,?);`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(postId, categoryId)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}

	return nil
}

func (c *categoryRepo) ReadCategoryByPost(postId int64) ([]model.Category, error) {
	query := `
	SELECT  Categories.id, Categories.name
	FROM Categories_Posts 
	JOIN Categories
		ON Categories_Posts.category_id = Categories.id
	WHERE post_id = ?;`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}
	row, err := stmt.Query(postId)
	if err != nil {
		return nil, err
	}

	categories := make([]model.Category, 0)

	for row.Next() {
		category := model.Category{}
		// maybe error here
		if err := category.ScanRow(row); err != nil {
			return nil, err
		}
		categories = append(categories, category)
	}

	return categories, nil
}

// func (c *categoryRepo) DeleteCategoryOnPost(post model.Post) error {
// 	query := `DELETE FROM Categories_Posts WHERE post_id = ?`

// 	stmt, err := c.db.Prepare(query)
// 	if err != nil {
// 		return err
// 	}

// 	res, err := stmt.Exec(post.Id)
// 	if err != nil {
// 		return err
// 	}

// 	row, err := res.RowsAffected()
// 	if err != nil {
// 		return err
// 	}

// 	if row != 1 {
// 		return model.ErrNotDBExecOne
// 	}

// 	return nil
// }
