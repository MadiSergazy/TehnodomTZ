package repository

import (
	"database/sql"

	"project/internal/model"
)

type reactionCommentRepo struct {
	db *sql.DB
}

func NewReactionCommentRepository(db *sql.DB) model.ReactionCommentRepository {
	return &reactionCommentRepo{
		db: db,
	}
}

func (r *reactionCommentRepo) CreateReactionComment(reac model.ReactionComment) (*model.ReactionComment, error) {
	query := `
	INSERT INTO Reactions_Comment (user_id,comment_id,type)
	VALUES (?,?,?);`

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	res, err := stmt.Exec(reac.UserId, reac.CommentId, reac.Type)
	if err != nil {
		return nil, err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return nil, err
	}
	if rows != 1 {
		return nil, sql.ErrNoRows
	}

	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}

	reac.Id = id

	return &reac, nil
}

func (r *reactionCommentRepo) GetReactionComment(commentId int64) (*model.Reaction, error) {
	query := `SELECT
	(SELECT COUNT(type) FROM Reactions_Comments WHERE type = 1 AND comment_id = $1) AS 'like',
	(SELECT COUNT(type) FROM Reactions_Comments WHERE type = -1 AND comment_id = $1) AS 'dislike'`

	reac := model.Reaction{}

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	row := stmt.QueryRow(commentId)
	if err := row.Err(); err != nil {
		return nil, err
	}

	if err := reac.ScanRow(row); err != nil {
		return nil, err
	}

	return &reac, nil
}

func (r *reactionCommentRepo) GetReactionCommentByUserId(commentId int64, userId int64) (*model.ReactionComment, error) {
	query := `
	SELECT * FROM Reactions_Comment WHERE comment_id = ? and user_id = ?;`

	reac := model.ReactionComment{}

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	row := stmt.QueryRow(commentId, userId)

	if err := row.Err(); err != nil {
		return nil, err
	}

	if err := reac.ScanRow(row); err != nil {
		return nil, err
	}

	return &reac, nil
}

func (r *reactionCommentRepo) UpdateReactionOnComment(reac model.ReactionComment) error {
	query := `
	UPDATE Reactions_Comment SET type = ? WHERE id = ?;`

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(reac.Type, reac.Id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}

	if rows != 1 {
		return sql.ErrNoRows
	}

	return nil
}
