package repository

import (
	"testing"

	"project/internal/model"
)

func TestUserRepository(t *testing.T) {
	// _, ok := interface{}(userRepo{}).(model.UserRepository)
	// if !ok {
	// 	t.Errorf("repo ")
	// }

	// userRepo := NewUserRepository(testDB)

	t.Run("create user", createUser)
}

func createUser(t *testing.T) {
	userRepo := NewUserRepository(testDB)
	testCase := []struct {
		name    string
		wantErr bool
		args    model.User
	}{
		{
			name:    "create user",
			wantErr: false,
			args: model.User{
				Name:     "Aldiyar",
				Email:    "Aldiyar@mail.com",
				Password: "123",
			},
		},
		{
			name:    "create existing user",
			wantErr: true,
			args: model.User{
				Name:     "Aldiyar",
				Email:    "Aldiyar@mail.com",
				Password: "123",
			},
		},
		{
			name:    "create existing name",
			wantErr: true,
			args: model.User{
				Name:     "Aldiyar",
				Email:    "Diar@mail.com",
				Password: "123",
			},
		},
		{
			name:    "create existing email",
			wantErr: true,
			args: model.User{
				Name:     "Diar",
				Email:    "Aldiyar@mail.com",
				Password: "123",
			},
		},
		{
			name:    "empty name",
			wantErr: true,
			args: model.User{
				Name:     "",
				Email:    "Aldiyar@mail.com",
				Password: "123",
			},
		},
		{
			name:    "empty email",
			wantErr: true,
			args: model.User{
				Name:     "Aldiyar",
				Email:    "",
				Password: "123",
			},
		},
		{
			name:    "empty name",
			wantErr: true,
			args: model.User{
				Name:     "Aldiyar",
				Email:    "Aldiyar@mail.com",
				Password: "123",
			},
		},
		{
			name:    "empty password",
			wantErr: true,
			args: model.User{
				Name:     "Aldiyar",
				Email:    "Aldiyar@mail.com",
				Password: "",
			},
		},
	}
	for _, c := range testCase {
		t.Run(c.name, func(t *testing.T) {
			if _, err := userRepo.CreateUser(c.args); err != nil && !c.wantErr {
				t.Error(err)
			} else {
				t.Log(c.name + "ok")
			}
		})
	}
}
