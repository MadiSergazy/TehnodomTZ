package repository

import (
	"database/sql"
	"time"

	"project/internal/model"
)

type postRepo struct {
	db *sql.DB
}

func NewPostRepository(db *sql.DB) model.PostRepository {
	return &postRepo{
		db: db,
	}
}

func (p *postRepo) CreatePost(post model.Post) (*model.Post, error) {
	query := `
	INSERT INTO Posts (user_id ,create_att ,title ,content)
	VALUES (?,?,?,?);`

	stmt, err := p.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	res, err := stmt.Exec(post.UserId, post.CreteAtt.Format(time.RFC3339), post.Title, post.Content)
	if err != nil {
		return nil, err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return nil, err
	}

	if rows != 1 {
		return nil, model.ErrNotExec
	}

	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	post.Id = id
	return &post, nil
}

func (p *postRepo) ReadAllPost() ([]model.Post, error) {
	query := `SELECT * FROM Posts;`

	stmt, err := p.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	rows, err := stmt.Query()
	if err != nil {
		return nil, err
	}

	posts := make([]model.Post, 0)
	for rows.Next() {
		post := model.Post{}
		if err := post.ScanRow(rows); err != nil {
			return nil, err
		}
		posts = append(posts, post)
	}

	if len(posts) == 0 {
		return nil, sql.ErrNoRows
	}

	return posts, nil
}

func (p *postRepo) ReadPostById(id int64) (*model.Post, error) {
	post := model.Post{}

	query := `SELECT * FROM Posts WHERE id = ?;`

	stmt, err := p.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	rows := stmt.QueryRow(id)

	if err := rows.Err(); err != nil {
		return nil, err
	}

	if err := post.ScanRow(rows); err != nil {
		return nil, err
	}

	return &post, nil
}

func (p *postRepo) ReadPostByUserId(userId int64) ([]model.Post, error) {
	query := `SELECT * FROM Posts user_id = ?;`

	stmt, err := p.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	rows, err := stmt.Query(userId)
	if err != nil {
		return nil, err
	}

	posts := make([]model.Post, 0)

	for rows.Next() {
		post := model.Post{}
		if err := post.ScanRow(rows); err != nil {
			return nil, err
		}
		posts = append(posts, post)
	}

	if len(posts) == 0 {
		return nil, sql.ErrNoRows
	}
	return posts, nil
}

func (p *postRepo) DeletePost(post model.Post) error {
	query := `
	DELETE FROM Posts WHERE id = ?`
	stmt, err := p.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(post.Id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}
	return nil
}
