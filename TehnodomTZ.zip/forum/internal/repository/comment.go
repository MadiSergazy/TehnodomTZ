package repository

import (
	"database/sql"

	"project/internal/model"
)

type commentRepo struct {
	db *sql.DB
}

func NewCommentRepository(db *sql.DB) model.CommentRepository {
	return &commentRepo{
		db: db,
	}
}

func (c *commentRepo) CreateComment(comment model.Comment) (*model.Comment, error) {
	query := `
	INSERT INTO Comments (user_id,post_id,content)
	VALUES (?,?,?);`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	res, err := stmt.Exec(comment.UserId, comment.PostId, comment.Content)
	if err != nil {
		return nil, err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return nil, err
	}

	if rows != 1 {
		return nil, sql.ErrNoRows
	}

	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	comment.Id = id

	return &comment, nil
}

func (c *commentRepo) CreateCommentOnComment(comment model.Comment) (*model.Comment, error) {
	query := `
	INSERT INTO Comments (user_id,post_id,parent_id,content)
	VALUES (?,?,?,?);`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	res, err := stmt.Exec(comment.UserId, comment.PostId, comment.ParentId, comment.Content)
	if err != nil {
		return nil, err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return nil, err
	}

	if rows != 1 {
		return nil, model.ErrNotExec
	}

	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	comment.Id = id

	return &comment, nil
}

func (c *commentRepo) ReadCommentById(id int64) (*model.Comment, error) {
	comment := model.Comment{}
	query := `SELECT * FROM Comments WHERE id = ?`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	row := stmt.QueryRow(id)

	if err := row.Err(); err != nil {
		return nil, err
	}

	if err := comment.ScanRow(row); err != nil {
		return nil, err
	}

	return &comment, nil
}

func (c *commentRepo) ReadCommentByPostId(postId int64) ([]model.Comment, error) {
	query := `SELECT * FROM Comments WHERE post_id = ?`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	rows, err := stmt.Query(postId)
	if err != nil {
		return nil, err
	}

	commments := make([]model.Comment, 0)

	for rows.Next() {
		commment := model.Comment{}

		if err := commment.ScanRow(rows); err != nil {
			return nil, err
		}

		commments = append(commments, commment)
	}

	return commments, nil
}

func (c *commentRepo) DeleteCommentId(comment model.Comment) error {
	query := `
	DELETE FROM Comments 
	WHERE id=?`

	stmt, err := c.db.Prepare(query)
	if err != nil {
		return err
	}
	res, err := stmt.Exec(comment.Id)
	if err != nil {
		return err
	}
	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}
	return nil
}
