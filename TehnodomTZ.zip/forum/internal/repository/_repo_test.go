package repository

import (
	"database/sql"
	"os"
	"project/internal/logger"
	"testing"

	util "project/internal/util/test"
)

var testDB *sql.DB

func TestMain(m *testing.M) {
	db, err := util.DBTest("../util/test/test_values")
	if err != nil {
		logger.FatalPrintln(err)
	}
	testDB = db

	codeExit := m.Run()

	os.Exit(codeExit)
}
