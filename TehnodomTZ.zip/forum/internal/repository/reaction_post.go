package repository

import (
	"database/sql"

	"project/internal/model"
)

type reactionPostRepo struct {
	db *sql.DB
}

func NewReactionPostRepository(db *sql.DB) model.ReactionPostRepository {
	return &reactionPostRepo{
		db: db,
	}
}

func (r *reactionPostRepo) CreateReactionOnPost(reac model.ReactionPost) (*model.ReactionPost, error) {
	query := `
	INSERT INTO Reactions_Posts (user_id,post_id,type)
	VALUES (?,?,?);`

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	res, err := stmt.Exec(reac.UserId, reac.PostId, reac.Type)
	if err != nil {
		return nil, err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return nil, err
	}
	if rows != 1 {
		return nil, sql.ErrNoRows
	}

	id, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}

	reac.Id = id

	return &reac, nil
}

func (r *reactionPostRepo) GetReactionPost(postId int64) (*model.Reaction, error) {
	query := `SELECT
	(SELECT COUNT(type) FROM Reactions_Posts WHERE type = 1 AND post_id = $1) AS 'like',
	(SELECT COUNT(type) FROM Reactions_Posts WHERE type = -1 AND post_id = $1) AS 'dislike'`
	reac := model.Reaction{}

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	row := stmt.QueryRow(postId)
	if err := row.Err(); err != nil {
		return nil, err
	}

	if err := reac.ScanRow(row); err != nil {
		return nil, err
	}

	return &reac, nil
}

func (r *reactionPostRepo) GetReactionPostByUserId(postId int64, userId int64) (*model.ReactionPost, error) {
	query := `
	SELECT * FROM Reactions_Posts WHERE post_id = ? and user_id = ?;`

	reac := model.ReactionPost{}

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return nil, err
	}

	row := stmt.QueryRow(postId, userId)

	if err := row.Err(); err != nil {
		return nil, err
	}

	if err := reac.ScanRow(row); err != nil {
		return nil, err
	}

	return &reac, nil
}

func (r *reactionPostRepo) UpdateReactionOnPost(reac model.ReactionPost) error {
	query := `
	UPDATE Reactions_Posts SET type = ? WHERE id = ?;`

	stmt, err := r.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(reac.Type, reac.Id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}

	if rows != 1 {
		return sql.ErrNoRows
	}

	return nil
}
