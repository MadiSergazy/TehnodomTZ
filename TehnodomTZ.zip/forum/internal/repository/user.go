package repository

import (
	"database/sql"

	"project/internal/model"
)

type userRepo struct {
	db *sql.DB
}

func NewUserRepository(db *sql.DB) model.UserRepository {
	return &userRepo{
		db: db,
	}
}

func (u *userRepo) CreateUser(user model.User) (model.User, error) {
	query := `
	INSERT INTO Users (name, email, password) 
	VALUES (?,?,?)`

	stmt, err := u.db.Prepare(query)
	if err != nil {
		return user, err
	}

	res, err := stmt.Exec(user.Name, user.Email, user.Password)
	if err != nil {
		return user, err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return user, err
	}

	if rows != 1 {
		return user, model.ErrNotExec
	}

	id, err := res.LastInsertId()
	if err != nil {
		return user, err
	}
	user.Id = id

	return user, nil
}

func (u *userRepo) ReadUserById(id int64) (model.User, error) {
	user := model.User{}

	query := `SELECT * FROM Users WHERE id = ?`

	stmt, err := u.db.Prepare(query)
	if err != nil {
		return user, err
	}

	row := stmt.QueryRow(id)

	if err := row.Err(); err != nil {
		return user, err
	}

	if err := user.ScanRow(row); err != nil {
		return user, err
	}

	return user, nil
}

func (u *userRepo) ReadUserByEmail(email string) (model.User, error) {
	user := model.User{}

	query := `SELECT * FROM Users WHERE email = ?`

	stmt, err := u.db.Prepare(query)
	if err != nil {
		return user, err
	}

	row := stmt.QueryRow(email)

	if err := row.Err(); err != nil {
		return user, err
	}

	if err := user.ScanRow(row); err != nil {
		return user, err
	}

	return user, nil
}

func (u *userRepo) ReadUserByName(name string) (model.User, error) {
	user := model.User{}

	query := `SELECT * FROM Users WHERE name = ?`

	stmt, err := u.db.Prepare(query)
	if err != nil {
		return user, err
	}

	row := stmt.QueryRow(name)

	if err := row.Err(); err != nil {
		return user, err
	}

	if err := user.ScanRow(row); err != nil {
		return user, err
	}

	return user, nil
}

func (u *userRepo) ReadUserForAuthorization(email string, password string) (model.User, error) {
	user := model.User{}

	query := `SELECT * FROM Users WHERE email = ? AND password = ?`

	stmt, err := u.db.Prepare(query)
	if err != nil {
		return user, err
	}

	row := stmt.QueryRow(email, password)

	if err := row.Err(); err != nil {
		return user, err
	}

	if err := user.ScanRow(row); err != nil {
		return user, err
	}

	return user, nil
}

func (u *userRepo) UpdateUserName(id int64, name string) error {
	query := `UPDATE Users SET name = ? WHERE id = ?`

	stmt, err := u.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(name, id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}
	return nil
}

func (u *userRepo) UpdateUserEmail(id int64, email string) error {
	query := `UPDATE Users SET email = ? WHERE id = ?`
	stmt, err := u.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(email, id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}
	return nil
}

func (u *userRepo) UpdateUserPassword(id int64, password string) error {
	query := `UPDATE Users SET password = ? WHERE id = ?`
	stmt, err := u.db.Prepare(query)
	if err != nil {
		return err
	}

	res, err := stmt.Exec(password, id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}
	return nil
}

func (u *userRepo) DeleteUser(user model.User) error {
	query := `
	DELETE FROM Users 
	WHERE name= ? AND email=? AND password=?`

	stmt, err := u.db.Prepare(query)
	if err != nil {
		return err
	}
	res, err := stmt.Exec(user.Name, user.Email, user.Password)
	if err != nil {
		return err
	}
	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}
	if rows != 1 {
		return model.ErrNotExec
	}
	return nil
}
