package handlers

import (
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"path"
	"strconv"
	"time"

	"project/internal/logger"
	"project/internal/model"
)

type post struct {
	PostService    model.PostService
	CommentService model.CommentService
}

func NewPostHandlers(PostService model.PostService, CommentService model.CommentService) model.PostHandlers {
	return &post{
		PostService:    PostService,
		CommentService: CommentService,
	}
}

func (p *post) Index(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		ErrorPage(w, http.StatusMethodNotAllowed)
		return
	}

	posts, err := p.PostService.ReadAllPost()
	if err != nil {
		logger.ErrorPrint(err)
		ErrorPage(w, http.StatusInternalServerError)
		return
	}

	for _, post := range posts {
		fmt.Fprintln(w, post)
	}
}

func (p *post) PostPage(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		ErrorPage(w, http.StatusMethodNotAllowed)
		return
	}

	postId, err := strconv.Atoi(path.Base(r.URL.Path))
	if err != nil {
		ErrorPage(w, http.StatusNotFound)
		return
	}

	post, err := p.PostService.PostById(int64(postId))
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			ErrorPage(w, http.StatusNotFound)
			return
		}
		ErrorPage(w, http.StatusInternalServerError)
		return
	}
	fmt.Fprintf(w, "post.Id: %v\n", post.Id)
	fmt.Fprintf(w, "post.Title: %v\n", post.Title)
	fmt.Fprintf(w, "post.Content: %v\n", post.Content)
	fmt.Fprintf(w, "post.Categories: %v\n", post.Categories)
	fmt.Fprintf(w, "post.Reaction: %v\n", post.Reaction)
	fmt.Fprintf(w, "post.UserId: %v\n", post.UserId)
	for _, v := range post.Comments {
		fmt.Fprintf(w, "v.Id: %v\n", v.Id)
		fmt.Fprintf(w, "v.PostId: %v\n", v.PostId)
		fmt.Fprintf(w, "v.UserId: %v\n", v.UserId)
		fmt.Fprintf(w, "v.ParentId: %v\n", v.ParentId)
		fmt.Fprintf(w, "v.Content: %v\n", v.Content)
		fmt.Fprintf(w, "v.Reaction: %v\n", v.Reaction)
	}
}

func (p *post) CreatePost(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		ErrorPage(w, http.StatusMethodNotAllowed)
		return
	}

	r.ParseForm()
	userId, err := strconv.Atoi(r.PostFormValue("user_id"))
	if err != nil {
		ErrorPage(w, http.StatusInternalServerError)
		return
	}

	categories := make([]model.Category, 0)

	for _, value := range r.PostForm["categories"] {
		categories = append(categories, model.Category{
			Name: value,
		})
	}

	post := model.Post{
		UserId:     int64(userId),
		CreteAtt:   time.Now(),
		Title:      r.PostFormValue("title"),
		Content:    r.PostFormValue("content"),
		Categories: categories,
	}

	_, err = p.PostService.CreatePost(post)
	if err != nil {
		logger.ErrorPrint(err)
		ErrorPage(w, http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/", http.StatusMovedPermanently)
}
