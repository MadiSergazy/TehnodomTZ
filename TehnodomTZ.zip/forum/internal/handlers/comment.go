package handlers

import (
	"net/http"

	"project/internal/model"
)

type comment struct {
	CommentService model.CommentService
}

func NewCommentHandlers(CommentService model.CommentService) model.CommentHandlers {
	return &comment{
		CommentService: CommentService,
	}
}

func (c *comment) CreateComment(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		ErrorPage(w, http.StatusMethodNotAllowed)
		return
	}
	r.ParseForm()

	comment := model.Comment{}

	if r.PostFormValue("parent_id") == "" {
		if err := comment.ParseFormWithOutParent(r.PostForm); err != nil {
			ErrorPage(w, http.StatusBadRequest)
			return
		}
		_, err := c.CommentService.CreateComment(comment)
		if err != nil {
			ErrorPage(w, http.StatusInternalServerError)
			return
		}
	} else {
		if err := comment.ParseFormWithParent(r.PostForm); err != nil {
			ErrorPage(w, http.StatusBadRequest)
			return
		}
		_, err := c.CommentService.CreateCommentOnComment(comment)
		if err != nil {
			ErrorPage(w, http.StatusInternalServerError)
			return
		}
	}

	http.Redirect(w, r, "", http.StatusOK)
}
