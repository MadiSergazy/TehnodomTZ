package handlers

import (
	"net/http"

	"project/internal/model"
)

type reaction struct {
	ReactionCommentService model.ReactionCommentService
	ReactionPostService    model.ReactionPostService
}

func NewReactionHandlers(ReactionCommentService model.ReactionCommentService, ReactionPostService model.ReactionPostService) model.ReactionHandlers {
	return &reaction{
		ReactionCommentService: ReactionCommentService,
		ReactionPostService:    ReactionPostService,
	}
}

func (reac *reaction) ReactionPost(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		ErrorPage(w, http.StatusMethodNotAllowed)
		return
	}
	r.ParseForm()

	re := model.ReactionPost{}
	if err := re.ParseForm(r.PostForm); err != nil {
		ErrorPage(w, http.StatusBadRequest)
		return
	}

	if err := reac.ReactionPostService.ReactionOnPost(re); err != nil {
		ErrorPage(w, http.StatusInternalServerError)
		return
	}
	http.Redirect(w, r, "/", http.StatusOK)
}

func (reac *reaction) ReactionComment(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		ErrorPage(w, http.StatusMethodNotAllowed)
		return
	}
	r.ParseForm()

	re := model.ReactionComment{}

	if err := re.ParseForm(r.PostForm); err != nil {
		ErrorPage(w, http.StatusBadRequest)
		return
	}

	if err := reac.ReactionCommentService.ReactionOnComment(re); err != nil {
		ErrorPage(w, http.StatusInternalServerError)
		return
	}
	http.Redirect(w, r, "/", http.StatusOK)
}
