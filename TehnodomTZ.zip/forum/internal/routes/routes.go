package routes

import (
	"database/sql"
	"net/http"

	"project/internal/handlers"
	"project/internal/logger"
	"project/internal/repository"
	"project/internal/service"
)

const (
	LogIn  = "/login"
	LogOut = "/logout"
	SignUp = "/signup"
)

func InitRoutes(db *sql.DB, mux *http.ServeMux) http.Handler {
	// repository

	logger.InfoPrintln("init repositories")
	// userRepo := repository.NewUserRepository(db)
	// sessionRepo := repository.NewSessionRepository(db)
	categoryRepo := repository.NewCategoryRepository(db)
	postRepo := repository.NewPostRepository(db, categoryRepo)
	commentRepo := repository.NewCommentRepository(db)
	reactionCommentRepo := repository.NewReactionCommentRepository(db)
	reactionPostRepo := repository.NewReactionPostRepository(db)

	// service
	logger.InfoPrintln("init service")
	// service.NewAuthService()
	reactionCommentService := service.NewReactionCommentService(commentRepo, reactionCommentRepo)
	reactionPostService := service.NewReactionPostService(postRepo, reactionPostRepo)
	commentService := service.NewCommentService(postRepo, commentRepo, reactionCommentService)
	postService := service.NewPostService(categoryRepo, postRepo, commentService, reactionPostService)

	// handlers
	logger.InfoPrintln("init handlers")
	reactionHandlers := handlers.NewReactionHandlers(reactionCommentService, reactionPostService)
	postHandlers := handlers.NewPostHandlers(postService, commentService)
	commentHandlers := handlers.NewCommentHandlers(commentService)

	// middleware
	logger.InfoPrintln("init middleware handlers")
	middleware := handlers.NewMiddlewareHandlers()

	// handlefunc
	logger.InfoPrintln("init mux")

	//----------------------------------------------------------------
	// Нужно покрыть middleware чтобы залогиненый человек мог только заходить
	mux.HandleFunc("/reaction-post", reactionHandlers.ReactionPost)
	mux.HandleFunc("/reaction-coment", reactionHandlers.ReactionComment)

	mux.HandleFunc("/comment", commentHandlers.CreateComment)

	mux.HandleFunc("/create-post", postHandlers.CreatePost)
	//----------------------------------------------------------------

	mux.HandleFunc("/post/", postHandlers.PostPage)
	mux.HandleFunc("/", postHandlers.Index)

	return middleware.PanicRecover(mux)
}
