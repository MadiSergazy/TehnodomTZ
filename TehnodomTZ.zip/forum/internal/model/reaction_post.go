package model

import (
	"net/url"
	"strconv"
)

type ReactionPost struct {
	Id     int64
	UserId int64
	PostId int64
	Type   int64
}

func (r *ReactionPost) ScanRow(row scan) error {
	return row.Scan(
		&r.Id,
		&r.UserId,
		&r.PostId,
		&r.Type,
	)
}

func (r *ReactionPost) ParseForm(form url.Values) error {
	userId, err := strconv.Atoi(form.Get("user_id"))
	if err != nil {
		return err
	}

	postId, err := strconv.Atoi(form.Get("post_id"))
	if err != nil {
		return err
	}

	typ, err := strconv.Atoi(form.Get("type"))
	if err != nil {
		return err
	}

	r.UserId = int64(userId)
	r.PostId = int64(postId)
	r.Type = int64(typ)

	return nil
}
