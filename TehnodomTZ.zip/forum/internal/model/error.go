package model

import "errors"

var ErrNotExec = errors.New("not executed")
