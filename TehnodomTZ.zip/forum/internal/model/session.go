package model

type Session struct {
	Id     int64
	UserId int64
	Token  string
	EndAtt string
}

func (s *Session) ScanRow(row scan) error {
	return row.Scan(
		&s.Id,
		&s.UserId,
		&s.Token,
		&s.EndAtt,
	)
}
