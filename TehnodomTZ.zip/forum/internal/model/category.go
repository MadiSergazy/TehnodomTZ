package model

import (
	"errors"
)

type Category struct {
	Id   int64
	Name string
}

func (u *Category) ScanRow(row scan) error {
	return row.Scan(
		&u.Id,
		&u.Name,
	)
}

type CategoryLink struct {
	PostId     int64
	CategoryId int64
}

func (c *CategoryLink) ScanRow(row scan) error {
	return row.Scan(
		c.PostId,
		c.CategoryId,
	)
}

func (c *Category) Validity() error {
	if haveSpace(c.Name) {
		return errors.New("")
	}
	return nil
}
