package model

type Reaction struct {
	Like    int64
	DisLike int64
}

func (r *Reaction) ScanRow(row scan) error {
	return row.Scan(
		&r.Like,
		&r.DisLike,
	)
}
