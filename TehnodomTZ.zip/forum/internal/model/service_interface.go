package model

type AuthService interface{}

type PostService interface {
	CreatePost(Post) (*Post, error)
	ReadAllPost() ([]Post, error)
	PostById(id int64) (*Post, error)
}

type ReactionPostService interface {
	ReactionOnPost(reac ReactionPost) error
	GetReactionPost(postId int64) (*Reaction, error)
}

type ReactionCommentService interface {
	ReactionOnComment(reac ReactionComment) error
	GetReactionComment(commentId int64) (*Reaction, error)
}

type CommentService interface {
	CreateComment(comment Comment) (*Comment, error)
	CreateCommentOnComment(comment Comment) (*Comment, error)
	CommentByPostId(postId int64) ([]Comment, error)
}
