package model

type UserRepository interface{}

type SessionRepository interface{}

type PostRepository interface {
	CreatePost(post Post) (*Post, error)
	ReadAllPost() ([]Post, error)
	ReadPostById(id int64) (*Post, error)
	ReadPostByUserId(userId int64) ([]Post, error)
	DeletePost(post Post) error
}

type CategoryRepository interface {
	CreateCategory(category Category) (*Category, error)
	GetCategoryByName(name string) (*Category, error)
	GetCategoryById(id int64) (*Category, error)
	// CreateCategoryOnPost on function first argument is the id of the post, second argument is the id of the category.
	CreateCategoryOnPost(postId, categoryId int64) error
	ReadCategoryByPost(postId int64) ([]Category, error)
}

type CommentRepository interface {
	CreateComment(comment Comment) (*Comment, error)
	CreateCommentOnComment(comment Comment) (*Comment, error)
	ReadCommentById(id int64) (*Comment, error)
	ReadCommentByPostId(postId int64) ([]Comment, error)
	DeleteCommentId(comment Comment) error
}

type ReactionPostRepository interface {
	CreateReactionOnPost(reac ReactionPost) (*ReactionPost, error)
	GetReactionPost(postId int64) (*Reaction, error)
	GetReactionPostByUserId(postId int64, userId int64) (*ReactionPost, error)
	UpdateReactionOnPost(reac ReactionPost) error
}

type ReactionCommentRepository interface {
	CreateReactionComment(reac ReactionComment) (*ReactionComment, error)
	GetReactionComment(commentId int64) (*Reaction, error)
	GetReactionCommentByUserId(commentId int64, userId int64) (*ReactionComment, error)
	UpdateReactionOnComment(reac ReactionComment) error
}

type scan interface {
	Scan(agr ...any) error
}
