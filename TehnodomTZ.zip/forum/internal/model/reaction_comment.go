package model

import (
	"net/url"
	"strconv"
)

type ReactionComment struct {
	Id        int64
	UserId    int64
	CommentId int64
	Type      int64
}

func (r *ReactionComment) ScanRow(row scan) error {
	return row.Scan(
		&r.Id,
		&r.UserId,
		&r.CommentId,
		&r.Type,
	)
}

func (r *ReactionComment) ParseForm(form url.Values) error {
	userId, err := strconv.Atoi(form.Get("user_id"))
	if err != nil {
		return err
	}

	commentId, err := strconv.Atoi(form.Get("comment_id"))
	if err != nil {
		return err
	}

	typ, err := strconv.Atoi(form.Get("type"))
	if err != nil {
		return err
	}

	r.UserId = int64(userId)
	r.CommentId = int64(commentId)
	r.Type = int64(typ)

	return nil
}
