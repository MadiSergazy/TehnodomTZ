package model

import (
	"errors"
	"strings"
	"time"
)

type Post struct {
	Id         int64
	UserId     int64
	CreteAtt   time.Time
	Title      string
	Content    string
	Categories []Category
	Comments   []Comment
	Reaction   Reaction
}

func (p *Post) ScanRow(row scan) error {
	var createAtt string

	if err := row.Scan(
		&p.Id,
		&p.UserId,
		&createAtt,
		&p.Title,
		&p.Content,
	); err != nil {
		return err
	}

	temp, err := time.Parse(time.RFC3339, createAtt)
	if err != nil {
		return err
	}
	p.CreteAtt = temp

	return nil
}

func (p *Post) Validity() error {
	if len(strings.TrimSpace(p.Title)) == 0 {
		return errors.New("")
	}
	if len(strings.TrimSpace(p.Content)) == 0 {
		return errors.New("")
	}
	// TODO: validate возмонжно нужно добавить
	return nil
}
