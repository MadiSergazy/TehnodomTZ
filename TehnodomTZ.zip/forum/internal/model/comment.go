package model

import (
	"database/sql"
	"errors"
	"net/url"
	"strconv"
	"strings"
)

type Comment struct {
	Id       int64
	UserId   int64
	PostId   int64
	ParentId int64
	Content  string
	Reaction Reaction
}

func (c *Comment) ParseFormWithParent(form url.Values) error {
	userId, err := strconv.Atoi(form.Get("user_id"))
	if err != nil {
		return err
	}

	postId, err := strconv.Atoi(form.Get("post_id"))
	if err != nil {
		return err
	}

	parenId, err := strconv.Atoi(form.Get("parent_id"))
	if err != nil {
		return err
	}

	c.UserId = int64(userId)
	c.PostId = int64(postId)
	c.ParentId = int64(parenId)
	c.Content = form.Get("content")
	return nil
}

func (c *Comment) ParseFormWithOutParent(form url.Values) error {
	userId, err := strconv.Atoi(form.Get("user_id"))
	if err != nil {
		return err
	}

	postId, err := strconv.Atoi(form.Get("post_id"))
	if err != nil {
		return err
	}

	c.UserId = int64(userId)
	c.PostId = int64(postId)
	c.Content = form.Get("content")
	return nil
}

func (c *Comment) ScanRow(row scan) error {
	var temp sql.NullInt64
	if err := row.Scan(
		&c.Id,
		&c.UserId,
		&c.PostId,
		&temp,
		&c.Content,
	); err != nil {
		return err
	}

	if temp.Valid {
		c.ParentId = temp.Int64
	}

	return nil
}

func (c *Comment) Validity() error {
	if len(strings.TrimSpace(c.Content)) == 0 {
		return errors.New("")
	}

	return nil
}
