package model

import (
	"errors"
	"unicode"
)

type User struct {
	Id       int64
	Email    string
	Name     string
	Password string
}

func (u *User) ScanRow(row scan) error {
	return row.Scan(
		&u.Id,
		&u.Name,
		&u.Email,
		&u.Password,
	)
}

func (u *User) Validity() error {
	if haveSpace(u.Email) {
		return errors.New("email have space")
	} else if haveSpace(u.Name) {
		return errors.New("name have space")
	} else if haveSpace(u.Password) {
		return errors.New("password have space")
	}

	// Здесть написать регулярки для полей
	return nil
}

func haveSpace(word string) bool {
	for _, let := range word {
		if unicode.IsSpace(let) {
			return true
		}
	}
	return false
}
