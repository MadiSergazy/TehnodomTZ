package model

import "net/http"

type AuthHandlers interface {
	LogIn(http.ResponseWriter, *http.Request)
	LogOut(http.ResponseWriter, *http.Request)
	SignUp(http.ResponseWriter, *http.Request)
}

type PostHandlers interface {
	Index(http.ResponseWriter, *http.Request)
	PostPage(http.ResponseWriter, *http.Request)
	CreatePost(http.ResponseWriter, *http.Request)
}

type CommentHandlers interface {
	CreateComment(http.ResponseWriter, *http.Request)
}

type ReactionHandlers interface {
	ReactionPost(http.ResponseWriter, *http.Request)
	ReactionComment(http.ResponseWriter, *http.Request)
}
