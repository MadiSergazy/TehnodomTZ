package app

import (
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"project/config"
	"project/internal/handlers"
	"project/internal/logger"
	"project/internal/routes"
	"project/internal/server"
	"project/pkg/sqlite"
)

var chanErr = make(chan error, 1)

func Run() error {
	logger.InfoPrintln("db connection")
	db, err := sqlite.Connect(config.C.Path.DB)
	if err != nil {
		return err
	}

	logger.InfoPrintln("read template")
	if err := handlers.ReadTemplate(config.C.Path.Template + "*.html"); err != nil {
		return err
	}

	logger.InfoPrintln("init mux")
	mux := http.NewServeMux()

	logger.InfoPrintln("init routes")
	router := routes.InitRoutes(db, mux)

	logger.InfoPrintln("init server")
	server := server.NewServer(router)

	go func() {
		logger.InfoPrintf("Starting listener on http://localhost%s", config.C.Server.Port)
		chanErr <- server.ListenAndServe()
	}()

	return wait()
}

func wait() error {
	syscalCh := make(chan os.Signal, 1)
	signal.Notify(syscalCh, syscall.SIGINT, syscall.SIGTERM)

	select {
	case <-syscalCh:
		fmt.Println()
		logger.InfoPrintln("Stop server...")
		return nil
	case err := <-chanErr:
		return err
	}
}
