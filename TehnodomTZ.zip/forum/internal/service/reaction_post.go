package service

import (
	"database/sql"
	"errors"

	"project/internal/model"
)

type reactionPost struct {
	PostRepository         model.PostRepository
	ReactionPostRepository model.ReactionPostRepository
}

func NewReactionPostService(p model.PostRepository, r model.ReactionPostRepository) model.ReactionPostService {
	return &reactionPost{
		PostRepository:         p,
		ReactionPostRepository: r,
	}
}

func (r *reactionPost) ReactionOnPost(reac model.ReactionPost) error {
	_, err := r.PostRepository.ReadPostById(reac.PostId)
	if err != nil {
		return err
	}

	re, err := r.ReactionPostRepository.GetReactionPostByUserId(reac.PostId, reac.UserId)

	switch {
	case err == nil:
		err = r.ReactionPostRepository.UpdateReactionOnPost(*re)
		if err != nil {
			return err
		}
	case errors.Is(err, sql.ErrNoRows):
		_, err = r.ReactionPostRepository.CreateReactionOnPost(reac)
		if err != nil {
			return err
		}
	default:
		return err
	}

	return nil
}

func (r *reactionPost) GetReactionPost(postId int64) (*model.Reaction, error) {
	_, err := r.PostRepository.ReadPostById(postId)
	if err != nil {
		return nil, err
	}

	reacs, err := r.ReactionPostRepository.GetReactionPost(postId)
	if err != nil {
		return nil, err
	}

	return reacs, nil
}
