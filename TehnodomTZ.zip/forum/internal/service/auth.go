package service

import (
	"project/internal/model"
)

type auth struct {
	UserRepository    model.UserRepository
	SessionRepository model.SessionRepository
}

func NewAuthService(UserRepository model.UserRepository, SessionRepository model.SessionRepository) model.AuthService {
	return &auth{
		UserRepository:    UserRepository,
		SessionRepository: SessionRepository,
	}
}

func (a *auth) SignUp(model.User) error {
	return nil
}
