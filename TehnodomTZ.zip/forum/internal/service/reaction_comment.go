package service

import (
	"database/sql"
	"errors"

	"project/internal/model"
)

type reactionComment struct {
	CommentRepository         model.CommentRepository
	ReactionCommentRepository model.ReactionCommentRepository
}

func NewReactionCommentService(p model.CommentRepository, r model.ReactionCommentRepository) model.ReactionCommentService {
	return &reactionComment{
		CommentRepository:         p,
		ReactionCommentRepository: r,
	}
}

func (r *reactionComment) ReactionOnComment(reac model.ReactionComment) error {
	_, err := r.CommentRepository.ReadCommentById(reac.CommentId)
	if err != nil {
		return err
	}

	re, err := r.ReactionCommentRepository.GetReactionCommentByUserId(reac.CommentId, reac.UserId)

	switch {
	case err == nil:
		r.ReactionCommentRepository.UpdateReactionOnComment(*re)
		if err != nil {
			return err
		}
	case errors.Is(err, sql.ErrNoRows):
		_, err = r.ReactionCommentRepository.CreateReactionComment(reac)
		if err != nil {
			return err
		}
	default:
		return err
	}

	return nil
}

func (r *reactionComment) GetReactionComment(commentId int64) (*model.Reaction, error) {
	_, err := r.CommentRepository.ReadCommentById(commentId)
	if err != nil {
		return nil, err
	}

	reacs, err := r.ReactionCommentRepository.GetReactionComment(commentId)
	if err != nil {
		return nil, err
	}

	return reacs, nil
}
