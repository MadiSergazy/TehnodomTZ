package service

import (
	"errors"

	"project/internal/model"
)

type comment struct {
	PostRepository    model.PostRepository
	CommentRepository model.CommentRepository
	Reaction          model.ReactionCommentService
}

func NewCommentService(PostRepository model.PostRepository, CommentRepository model.CommentRepository, Reaction model.ReactionCommentService) model.CommentService {
	return &comment{
		PostRepository:    PostRepository,
		CommentRepository: CommentRepository,
		Reaction:          Reaction,
	}
}

func (c *comment) CreateComment(comment model.Comment) (*model.Comment, error) {
	if err := comment.Validity(); err != nil {
		return nil, err
	}

	if !c.validPost(comment.PostId) {
		return nil, errors.New("invalid post")
	}

	com, err := c.CommentRepository.CreateComment(comment)
	if err != nil {
		return nil, err
	}
	if com == nil {
		return nil, errors.New("not found comment")
	}

	return com, nil
}

func (c *comment) CreateCommentOnComment(comment model.Comment) (*model.Comment, error) {
	if err := comment.Validity(); err != nil {
		return nil, err
	}

	if !c.validPost(comment.PostId) {
		return nil, errors.New("invalid post")
	}

	_, err := c.CommentRepository.ReadCommentById(comment.ParentId)
	if err != nil {
		return nil, err
	}

	com, err := c.CommentRepository.CreateCommentOnComment(comment)
	if err != nil {
		return nil, err
	}

	if com == nil {
		return nil, errors.New("not found comment")
	}

	return com, nil
}

func (c *comment) CommentByPostId(postId int64) ([]model.Comment, error) {
	if !c.validPost(postId) {
		return nil, errors.New("invalid post")
	}

	comments, err := c.CommentRepository.ReadCommentByPostId(postId)
	if err != nil {
		return nil, err
	}

	for i, commnet := range comments {
		reac, err := c.Reaction.GetReactionComment(commnet.Id)
		if err != nil {
			return nil, err
		}
		commnet.Reaction = *reac

		comments[i] = commnet
	}

	return comments, nil
}

func (c *comment) validPost(postId int64) bool {
	post, err := c.PostRepository.ReadPostById(postId)
	if err != nil || post == nil {
		return false
	}

	return true
}
