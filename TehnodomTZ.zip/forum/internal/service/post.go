package service

import (
	"database/sql"
	"errors"

	"project/internal/model"
)

type post struct {
	CategoryRepository model.CategoryRepository
	PostRepository     model.PostRepository
	CommentService     model.CommentService
	ReactionPost       model.ReactionPostService
}

func NewPostService(
	CategoryRepository model.CategoryRepository,
	PostRepository model.PostRepository,
	CommentService model.CommentService,
	ReactionPost model.ReactionPostService,
) model.PostService {
	return &post{
		CategoryRepository: CategoryRepository,
		PostRepository:     PostRepository,
		CommentService:     CommentService,
		ReactionPost:       ReactionPost,
	}
}

func (p *post) CreatePost(post model.Post) (*model.Post, error) {
	if err := post.Validity(); err != nil {
		return nil, err
	}

	for i, category := range post.Categories {
		if err := category.Validity(); err != nil {
			return nil, err
		}

		catRes, err := p.CategoryRepository.GetCategoryByName(category.Name)
		if catRes == nil {
			catRes, err = p.CategoryRepository.CreateCategory(category)
			if err != nil {
				return nil, err
			}
		}
		post.Categories[i] = *catRes
	}

	pos, err := p.PostRepository.CreatePost(post)
	if err != nil {
		return nil, err
	}

	for _, category := range post.Categories {
		if err := p.CategoryRepository.CreateCategoryOnPost(pos.Id, category.Id); err != nil {
			return nil, err
		}
	}

	return pos, nil
}

func (p *post) ReadAllPost() ([]model.Post, error) {
	posts, err := p.PostRepository.ReadAllPost()
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
		} else {
			return nil, err
		}
	}

	for i, post := range posts {
		cat, err := p.CategoryRepository.ReadCategoryByPost(post.Id)
		if err != nil {
			return nil, err
		}

		posts[i].Categories = cat
	}

	return posts, nil
}

func (p *post) PostById(postId int64) (*model.Post, error) {
	post, err := p.PostRepository.ReadPostById(postId)
	if err != nil {
		return nil, err
	}
	post.Categories, err = p.CategoryRepository.ReadCategoryByPost(post.Id)
	if err != nil {
		return nil, err
	}

	post.Comments, err = p.CommentService.CommentByPostId(postId)
	if err != nil {
		return nil, err
	}

	reac, err := p.ReactionPost.GetReactionPost(postId)
	if err != nil {
		return nil, err
	}

	post.Reaction = *reac

	return post, nil
}
