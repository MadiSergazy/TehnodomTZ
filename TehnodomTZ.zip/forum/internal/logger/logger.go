package logger

import (
	"log"
	"os"
)

var (
	red    = "\033[31m"
	yellow = "\033[33m"
	reset  = "\033[0m"

	InfoLog  *log.Logger = log.New(os.Stdout, yellow+"[INFO]\t"+reset, log.Ldate|log.Ltime)
	ErrorLog *log.Logger = log.New(os.Stdout, red+"[ERROR]\t"+reset, log.Ldate|log.Ltime|log.Lshortfile)
)

func InfoPrintln(v ...any) {
	InfoLog.Println(v...)
}

func InfoPrintf(format string, v ...any) {
	InfoLog.Printf(format, v...)
}

func ErrorPrint(err error) {
	ErrorLog.Output(2, err.Error())
}

func FatalPrintln(err error) {
	ErrorLog.Fatalln(err)
}
