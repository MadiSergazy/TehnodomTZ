package main

import (
	"project/config"
	"project/internal/app"
	"project/internal/logger"
)

func main() {
	if err := config.ReadConfig(); err != nil {
		logger.FatalPrintln(err)
	}

	if err := app.Run(); err != nil {
		logger.FatalPrintln(err)
	}
}
