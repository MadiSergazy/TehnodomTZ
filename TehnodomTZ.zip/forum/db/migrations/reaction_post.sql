CREATE TABLE Reactions_Posts (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL CHECK(user_id > 0),
    post_id INTEGER NOT NULL CHECK(post_id > 0),
    type INTEGER NOT NULL CHECK(type = -1 OR type = 1 OR type = 0), 
    FOREIGN KEY (user_id) REFERENCES Users(id),
    FOREIGN KEY (post_id) REFERENCES Posts(id)
);
