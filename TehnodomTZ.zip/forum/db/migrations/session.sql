CREATE TABLE Session (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL CHECK(user_id > 0),
    token TEXT NOT NULL CHECK(token <> '' AND length(token) = 36 ),
    session_end_time TEXT NOT NULL CHECK(session_end_time <> ''),
    FOREIGN KEY (user_id) REFERENCES Users(id)
);
