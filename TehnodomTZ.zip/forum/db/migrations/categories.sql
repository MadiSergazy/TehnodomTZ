CREATE TABLE Categories (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE CHECK(name <> '')
);

 