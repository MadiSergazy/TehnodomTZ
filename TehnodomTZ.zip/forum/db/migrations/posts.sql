CREATE TABLE Posts (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL CHECK(user_id > 0),
    create_att TEXT  NOT NULL CHECK(create_att <> ''),
    title TEXT NOT NULL CHECK(title <> ''),
    content TEXT NOT NULL CHECK(content <> ''),
    FOREIGN KEY (user_id) REFERENCES Users(id)
);