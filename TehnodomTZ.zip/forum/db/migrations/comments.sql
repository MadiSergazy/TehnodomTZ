CREATE TABLE Comments (
    id INTEGER PRIMARY KEY ,
    user_id INTEGER NOT NULL CHECK(user_id > 0),
    post_id INTEGER NOT NULL CHECK(post_id > 0),
    parent_id INTEGER CHECK(parent_id > 0),
    content TEXT NOT NULL CHECK(content <> ''),
    FOREIGN KEY (user_id) REFERENCES Users(id), 
    FOREIGN KEY (post_id) REFERENCES Posts(id),
    FOREIGN KEY (parent_id) REFERENCES Comments(id)
);
