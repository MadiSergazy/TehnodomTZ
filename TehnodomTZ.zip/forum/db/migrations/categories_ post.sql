CREATE TABLE Categories_Posts (
    post_id INTEGER NOT NULL CHECK(post_id > 0),
    category_id INTEGER NOT NULL CHECK(category_id > 0),
    FOREIGN KEY (post_id) REFERENCES Post(id),
    FOREIGN KEY (category_id) REFERENCES Category(id)
);
