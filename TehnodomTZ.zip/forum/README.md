# forum

run program
    
    go run cmd/forum/main.go
